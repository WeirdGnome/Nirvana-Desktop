// Nirvana Desktop - denise: the file manager's spatial memory
// Every folder remembers where and how large its window was, and whether it was open.
// File: $XDG_CONFIG_HOME/nirvana/windows (by default ~/.config/...)
#pragma once
#include <map>
#include <string>
#include <vector>

struct WinState {
  int x = 0, y = 0, w = 0, h = 0;
  bool shaded = false;
  bool open = false;
  bool list = true;    // list view instead of icons (the list is the default)
  int icons = 32;      // icon size: 16, 32, 64
};

class Spatial {
public:
  explicit Spatial(const std::string &home);
  bool get(const std::string &path, WinState &out) const;
  void set(const std::string &path, const WinState &s);
  std::vector<std::string> open_paths() const;   // windows open at exit
  // Rambler 0.0.59: the list became the default view - the folders remembered with the old
  // default (icons) are shown as a list once (a marker file: only the first time)
  void list_default_once();
  // Rambler 0.0.61: the applications (and their category folders) are big icons by default,
  // like the Preferences window - remembered as a list in 0.0.59-0.0.60, switched once
  void apps_icons_once(const std::string &apps);
  void save() const;

private:
  std::string file_;
  std::map<std::string, WinState> map_;
};
