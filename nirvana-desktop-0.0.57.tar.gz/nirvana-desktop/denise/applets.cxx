// Nirvana Desktop - menu bar applets: volume and power
#include "applets.h"
#include "applet_ui.h"

#include "audio.h"
#include "platinum.h"
#include "power.h"

#include <FL/Fl.H>
#include <FL/Fl_Box.H>
#include <FL/Fl_Button.H>
#include <FL/Fl_Check_Button.H>
#include <FL/Fl_Choice.H>
#include <FL/Fl_Double_Window.H>
#include <FL/Fl_Slider.H>
#include <FL/fl_draw.H>
#include <FL/platform.H>

#include <X11/XF86keysym.h>
#include <X11/Xlib.h>
#include <X11/extensions/scrnsaver.h>

#include <algorithm>
#include <cstring>
#include <memory>

using namespace plat;

namespace applets {

static Host g_host;
static audio::State g_audio;
static power::State g_power;

// ---------------------------------------------------------------------------
// OSD: a volume/brightness bar at the bottom of the screen
// ---------------------------------------------------------------------------
class Osd : public Fl_Double_Window {
public:
  enum Kind { Volume, Brightness } kind = Volume;
  int value = 0;
  bool muted = false;
  Osd() : Fl_Double_Window(250, 64) { border(0); set_override(); end(); }
  void draw() override {
    fl_draw_box(UP_BOX, 0, 0, w(), h(), GRAY);
    fl_color(DARK);
    fl_rect(0, 0, w(), h());
    if (kind == Volume) draw_speaker(12, 13, muted ? 0 : 3, muted, TEXT, 2.6);
    else draw_sun(12, 14, TEXT, 2.6);
    int segs = 16, sx = 66, sw = 9, gap = 2, sy = 22, sh = 20;
    int lit = muted ? 0 : (value * segs + 50) / 100;
    for (int i = 0; i < segs; i++) {
      fl_draw_box(i < lit ? THUMB_BOX : WELL_BOX, sx + i * (sw + gap), sy, sw, sh, i < lit ? SEL : CONTENT);
    }
  }
  void pop(Kind k, int v, bool m) {
    kind = k; value = v; muted = m;
    int sx, sy, sw, sh;
    Fl::screen_xywh(sx, sy, sw, sh);
    position(sx + (sw - w()) / 2, sy + sh - h() - 90);
    show();
    redraw();
    Fl::remove_timeout(hide_cb, this);
    Fl::add_timeout(1.5, hide_cb, this);
  }
  static void hide_cb(void *d) { ((Osd *)d)->hide(); }
};
static Osd *g_osd;
static void osd(Osd::Kind k, int v, bool m) {
  if (!g_osd) g_osd = new Osd();
  g_osd->pop(k, v, m);
}

// ---------------------------------------------------------------------------
// Volume
// ---------------------------------------------------------------------------
class VolumeApplet;
static VolumeApplet *g_vol;

class VolumeApplet : public Fl_Widget {
public:
  VolumeApplet(int X, int Y, int W, int H) : Fl_Widget(X, Y, W, H) { g_vol = this; }
  Popup *pop = nullptr;
  std::string layout_key;   // what is in the popup (devices, streams) - a change = rebuild
  struct Row { PSlider *slider; Fl_Box *pct; Fl_Check_Button *mute; };
  Row out{}, in{};
  std::vector<std::pair<int, Row>> streams;   // stream index -> row

  void draw() override {
    fl_push_clip(x(), y(), w(), h());
    fl_draw_box(MENUBAR_BOX, x(), y(), w(), h(), GRAY);
    fl_pop_clip();
    bool open = pop && pop->shown();
    if (open) { fl_color(SEL); fl_rectf(x(), y(), w(), h() - 1); }
    Fl_Color c = open ? SEL_TEXT : TEXT;
    const audio::Device *d = g_audio.sink();
    int lvl = !d ? 0 : d->volume == 0 ? 0 : d->volume < 34 ? 1 : d->volume < 67 ? 2 : 3;
    draw_speaker(x() + (w() - 16) / 2, y() + 3, lvl, !d || d->mute || d->volume == 0,
                 d ? c : fl_color_average(c, GRAY, 0.4f));
  }
  int handle(int e) override {
    if (e == FL_PUSH) {
      if (pop && pop->shown()) { pop->close(); return 1; }
      open_popup();
      return 1;
    }
    // only over the icon: FLTK also offers the wheel to widgets away from the pointer
    // when nothing under it wants it (the whole desktop changed the volume)
    if (e == FL_MOUSEWHEEL) {
      if (!Fl::event_inside(this) || !Fl::event_dy()) return 0;
      audio::step_volume(-Fl::event_dy() * 5);
      refresh(true);
      return 1;
    }
    if (e == FL_ENTER || e == FL_LEAVE) return 1;
    return Fl_Widget::handle(e);
  }

  static std::string key_of(const audio::State &s) {
    std::string k = std::to_string((int)s.backend) + "|" + s.def_sink + "|" + s.def_source + "|";
    for (auto &d : s.sinks) k += d.name + ":" + d.active_port + ",";
    for (auto &d : s.sources) k += d.name + ":" + d.active_port + ",";
    for (auto &t : s.streams) k += std::to_string(t.index) + "@" + std::to_string(t.sink) + ",";
    return k;
  }

  void build() {
    const int W = 300;
    pop->begin();
    pop->clear();             // clear() sets resizable(this) - turn it off again
    pop->resizable(nullptr);
    pop->begin();
    int y = 8;
    streams.clear();
    out = in = Row{};
    const audio::State &s = g_audio;
    if (s.backend == audio::State::NoBackend) {
      text_box(12, y, W - 24, _("Sound"), true);
      y += 22;
      auto *b = text_box(12, y, W - 24, s.problem.c_str(), false, 36);
      b->align(FL_ALIGN_LEFT | FL_ALIGN_TOP | FL_ALIGN_INSIDE | FL_ALIGN_WRAP);
      y += 44;
    } else {
      auto device_rows = [&](bool output, Row &row, int &y) {
        const audio::Device *d = output ? s.sink() : s.source();
        const auto &list = output ? s.sinks : s.sources;
        text_box(12, y, 160, output ? _("Volume") : _("Microphone"), true);
        if (!d) {
          y += 22;
          text_box(12, y, W - 24, output ? _("No sound output.") : _("No microphone."));
          y += 24;
          return;
        }
        std::string dev = d->name;
        row.mute = check(W - 92, y - 1, 84, _("Mute"), d->mute, [output, dev](bool v) {
          audio::set_mute(g_audio, output, dev, v);
        });
        y += 22;
        row.slider = new PSlider(12, y, W - 70, 18);
        row.slider->value(std::min(100, d->volume));
        row.slider->callback([](Fl_Widget *w, void *o) {
          bool output = o != nullptr;
          const audio::Device *d = output ? g_audio.sink() : g_audio.source();
          if (!d) return;
          int v = (int)((PSlider *)w)->value();
          audio::set_volume(g_audio, output, d->name, v);
          if (output && d->mute && v > 0) audio::set_mute(g_audio, true, d->name, false);
          Row &r = output ? g_vol->out : g_vol->in;
          if (r.pct) { r.pct->copy_label((std::to_string(v) + "%").c_str()); r.pct->redraw(); }
        }, output ? (void *)1 : nullptr);
        row.pct = text_box(W - 52, y, 44, (std::to_string(d->volume) + "%").c_str());
        row.pct->align(FL_ALIGN_RIGHT | FL_ALIGN_INSIDE);
        y += 26;
        // device choice (and port, when there are several: speakers/headphones)
        if (s.backend == audio::State::Pulse && (list.size() > 1 || d->ports.size() > 1)) {
          auto *ch = new GrabChoice(82, y, W - 94, 22, output ? _("Output:") : _("Input:"));
          static std::vector<std::pair<std::string, std::string>> opts_out, opts_in;   // device, port
          auto &opts = output ? opts_out : opts_in;
          opts.clear();
          int sel = 0;
          for (auto &dv : list) {
            auto esc = [](std::string t) {
              std::string r;
              for (char c : t) { if (c == '/' || c == '\\' || c == '&' || c == '_') r += '\\'; r += c; }
              return r;
            };
            if (dv.ports.size() > 1) {
              for (auto &p : dv.ports) {
                if (!p.available && !(dv.name == d->name && p.name == dv.active_port)) continue;
                if (dv.name == d->name && p.name == dv.active_port) sel = (int)opts.size();
                opts.push_back({dv.name, p.name});
                ch->add(esc(dv.desc + " — " + p.desc).c_str());
              }
            } else {
              if (dv.name == d->name) sel = (int)opts.size();
              opts.push_back({dv.name, ""});
              ch->add(esc(dv.desc).c_str());
            }
          }
          ch->value(sel);
          ch->callback([](Fl_Widget *w, void *o) {
            bool output = o != nullptr;
            auto &opts = output ? opts_out : opts_in;
            int v = ((Fl_Choice *)w)->value();
            if (v < 0 || v >= (int)opts.size()) return;
            const audio::Device *cur = output ? g_audio.sink() : g_audio.source();
            if (!cur || cur->name != opts[v].first) audio::set_default(output, opts[v].first);
            if (!opts[v].second.empty()) audio::set_port(output, opts[v].first, opts[v].second);
          }, output ? (void *)1 : nullptr);
          y += 30;
        }
      };
      device_rows(true, out, y);
      new Sep(8, y, W - 16);
      y += 10;
      device_rows(false, in, y);
      if (!s.streams.empty()) {
        new Sep(8, y, W - 16);
        y += 10;
        text_box(12, y, W - 24, _("Applications"), true);
        y += 24;
        for (auto &t : s.streams) {
          if (streams.size() >= 8) break;
          Row r{};
          text_box(12, y, 100, t.app.c_str());
          int idx = t.index;
          r.mute = new Fl_Check_Button(112, y, 20, 20);
          r.mute->value(!t.mute);   // checked = audible
          r.mute->tooltip(_("This application is audible"));
          r.mute->callback([](Fl_Widget *w, void *i) {
            audio::set_stream_mute((int)(long)i, !((Fl_Check_Button *)w)->value());
          }, (void *)(long)idx);
          r.slider = new PSlider(136, y + 1, W - 148, 18);
          r.slider->value(std::min(100, t.volume));
          r.slider->callback([](Fl_Widget *w, void *i) {
            audio::set_stream_volume((int)(long)i, (int)((PSlider *)w)->value());
          }, (void *)(long)idx);
          streams.push_back({idx, r});
          y += 24;
        }
      }
    }
    pop->end();
    pop->size(W, y + 6);
    layout_key = key_of(s);
  }

  // A new state from the server: with the same devices only the values, otherwise a rebuild.
  void sync() {
    redraw();
    if (!pop || !pop->shown()) return;
    if (key_of(g_audio) != layout_key) {
      if (Fl::pushed()) return;   // no rebuild while dragging
      int X = pop->x(), Y = pop->y();
      build();
      pop->position(X, Y);
      pop->redraw();
      return;
    }
    auto upd = [](Row &r, int vol, bool mute, bool mute_is_on) {
      if (r.slider && Fl::pushed() != r.slider) { r.slider->value(std::min(100, vol)); r.slider->redraw(); }
      if (r.pct) { r.pct->copy_label((std::to_string(vol) + "%").c_str()); r.pct->redraw(); }
      if (r.mute) { r.mute->value(mute_is_on ? mute : !mute); r.mute->redraw(); }
    };
    if (auto *d = g_audio.sink()) upd(out, d->volume, d->mute, true);
    if (auto *d = g_audio.source()) upd(in, d->volume, d->mute, true);
    for (auto &[idx, r] : streams)
      for (auto &t : g_audio.streams) if (t.index == idx) upd(r, t.volume, t.mute, false);
  }

  void open_popup() {
    g_audio = audio::query();
    if (!pop) {
      pop = new Popup(300, 100);
      pop->on_close = [this] { redraw(); };
    }
    build();
    pop->open_at(x_root() + w() - pop->w(), window()->y_root() + MENUBAR_H);
    redraw();
  }

  int x_root() const { return window()->x_root() + x(); }

  void refresh(bool show_osd) {
    g_audio = audio::query();
    sync();
    if (show_osd)
      if (const audio::Device *d = g_audio.sink()) osd(Osd::Volume, d->volume, d->mute);
  }
};

Fl_Widget *make_volume(int X, int Y, int W, int H) { return new VolumeApplet(X, Y, W, H); }

// ---------------------------------------------------------------------------
// Power
// ---------------------------------------------------------------------------
class PowerApplet;
static PowerApplet *g_pow;

class PowerApplet : public Fl_Widget {
public:
  PowerApplet(int X, int Y, int W, int H) : Fl_Widget(X, Y, W, H) { g_pow = this; }
  Popup *pop = nullptr;
  PSlider *bright = nullptr;
  Fl_Box *bat_label = nullptr;

  void draw() override {
    fl_push_clip(x(), y(), w(), h());
    fl_draw_box(MENUBAR_BOX, x(), y(), w(), h(), GRAY);
    fl_pop_clip();
    bool open = pop && pop->shown();
    if (open) { fl_color(SEL); fl_rectf(x(), y(), w(), h() - 1); }
    Fl_Color c = open ? SEL_TEXT : TEXT;
    // to the right - the applets sit tightly, without a gap before the volume icon
    int iw = g_power.percent >= 0 ? 23 : 14;
    int ix = x() + w() - 4 - iw;
    int lx = ix;   // what goes before the battery
    if (g_power.percent >= 0) {
      draw_battery(ix, y() + 4, g_power.percent, g_power.charging, c);
      if (!g_power.charging && !g_power.on_ac) {        // discharging: an arrow pointing down
        lx -= 8;
        fl_color(g_power.percent <= 10 ? fl_rgb_color(0xC0, 0x20, 0x20) : c);
        fl_rectf(lx + 2, y() + 4, 2, 5);
        fl_polygon(lx, y() + 8, lx + 6, y() + 8, lx + 3, y() + 12);
      } else if (!g_power.charging) {                   // on the adapter and full: a small plug
        lx -= 9;
        fl_color(c);
        fl_rectf(lx + 1, y() + 4, 1, 3);
        fl_rectf(lx + 5, y() + 4, 1, 3);
        fl_rectf(lx, y() + 7, 7, 3);
        fl_rectf(lx + 2, y() + 10, 3, 1);
        fl_rectf(lx + 3, y() + 11, 1, 3);
      }
    } else {
      draw_plug(ix, y() + 3, c);
    }
    if (power::projection()) draw_display(lx - 14, y() + 5, c);   // projection mode: a monitor before the icons
  }
  int handle(int e) override {
    if (e == FL_PUSH) {
      if (pop && pop->shown()) { pop->close(); return 1; }
      open_popup();
      return 1;
    }
    if (e == FL_ENTER || e == FL_LEAVE) return 1;
    return Fl_Widget::handle(e);
  }

  static void act(Fl_Widget *w, void *d);
  void build() {
    const int W = 290;
    pop->begin();
    pop->clear();             // clear() sets resizable(this) - turn it off again
    pop->resizable(nullptr);
    pop->begin();
    int y = 8;
    std::string head = g_power.percent >= 0 ? plat::fmt(_("Battery: %1"), power::battery_text(g_power)) : std::string(_("AC power"));
    bat_label = text_box(12, y, W - 24, head.c_str(), true);
    y += 24;
    if (g_power.brightness >= 0) {
      struct Sun : Fl_Widget {
        Sun(int X, int Y) : Fl_Widget(X, Y, 14, 14) {}
        void draw() override { draw_sun(x(), y(), TEXT); }
      };
      new Sun(12, y + 2);
      bright = new PSlider(34, y, W - 46, 18);
      bright->bounds(1, 100);
      bright->value(g_power.brightness);
      bright->callback([](Fl_Widget *w, void *) { power::set_brightness(g_power, (int)((PSlider *)w)->value()); });
      y += 28;
    } else {
      bright = nullptr;
    }
    if (!g_power.profiles.empty()) {
      auto *ch = new GrabChoice(70, y, W - 82, 22, _("Profile:"));
      int sel = 0;
      for (size_t i = 0; i < g_power.profiles.size(); i++) {
        ch->add(power::profile_name(g_power.profiles[i]));
        if (g_power.profiles[i] == g_power.profile) sel = (int)i;
      }
      ch->value(sel);
      ch->callback([](Fl_Widget *w, void *) {
        int v = ((Fl_Choice *)w)->value();
        if (v < 0 || v >= (int)g_power.profiles.size()) return;
        if (power::set_profile(g_power.profiles[v])) { g_power.profile = g_power.profiles[v]; return; }
        // not changed (no permission, no way to change it): show the real state again
        for (size_t i = 0; i < g_power.profiles.size(); i++)
          if (g_power.profiles[i] == g_power.profile) ((Fl_Choice *)w)->value((int)i);
        w->redraw();
      });
      y += 30;
    }
    new Sep(8, y, W - 16);
    y += 10;
    auto *pj = check(10, y, W - 20, _("Presentation Mode"), power::projection(), [](bool on) {
      power::set_projection(on);
      if (g_pow) g_pow->sync();
    });
    pj->labelfont(FONT_SYSTEM);
    pj->labelsize(SIZE_SYSTEM);
    y += 22;
    auto *hint = text_box(30, y, W - 40, _("The screen will not turn off or lock, and the computer will not sleep."), false, 30);
    hint->labelsize(SIZE_SMALL);
    hint->align(FL_ALIGN_LEFT | FL_ALIGN_TOP | FL_ALIGN_INSIDE | FL_ALIGN_WRAP);
    y += 32;
    // lock, sleep, log out, shut down... are in the System menu of the menu bar
    new Sep(8, y, W - 16);
    y += 8;
    auto *r = new MenuRow(2, y, W - 4, _("Power Settings…"));
    r->callback(act, (void *)7L);
    y += 22;
    pop->end();
    pop->size(W, y + 4);
  }

  void open_popup() {
    g_power = power::query();
    if (!pop) {
      pop = new Popup(290, 100);
      pop->on_close = [this] {
        for (int i = 0; i < pop->children(); i++)   // after closing without highlights
          if (auto *r = dynamic_cast<MenuRow *>(pop->child(i))) r->hover(false);
        redraw();
      };
      pop->track_hover = [this] { update_hover(pop); };
    }
    build();
    pop->open_at(window()->x_root() + x() + w() - pop->w(), window()->y_root() + MENUBAR_H);
    redraw();
  }

  void sync() {
    redraw();
    if (w() != power_width() && g_host.relayout) g_host.relayout();
    if (!pop || !pop->shown()) return;
    if (bat_label) {
      std::string head = g_power.percent >= 0 ? plat::fmt(_("Battery: %1"), power::battery_text(g_power)) : std::string(_("AC power"));
      bat_label->copy_label(head.c_str());
      bat_label->redraw();
    }
    if (bright && Fl::pushed() != bright && g_power.brightness >= 0) { bright->value(g_power.brightness); bright->redraw(); }
  }
};

static void confirm(const char *title, const char *text, const char *yes, std::function<void()> f) {
  if (g_host.dialog) g_host.dialog(_(title), _(text), {{_("Cancel"), nullptr}, {_(yes), f}});
  else f();
}
static void report(const std::string &err) {
  if (!err.empty() && g_host.dialog) g_host.dialog(plat::GURU_TITLE, err, {{"OK", nullptr}});
}

void PowerApplet::act(Fl_Widget *, void *d) {
  long id = (long)d;
  if (g_pow && g_pow->pop) g_pow->pop->close();
  switch (id) {
    case 1: power::lock_screen(); break;
    case 2:
      if (power::projection()) { report(_("Presentation mode is on - turn it off to put the computer to sleep.")); break; }
      if (g_host.nirvana_session) power::lock_screen();   // after waking up the screen is locked
      report(power::suspend());
      break;
    case 3:
      if (power::projection()) { report(_("Presentation mode is on - turn it off to hibernate the computer.")); break; }
      report(power::hibernate());
      break;
    case 4:
      confirm(N_("Log Out"), N_("End the session? Open programs will be closed."), N_("Log Out"), [] {
        if (g_host.logout) g_host.logout();
      });
      break;
    case 5:
      confirm(N_("Restart"), N_("Restart the computer?"), N_("Restart"), [] {
        if (g_host.before_shutdown) g_host.before_shutdown();
        report(power::reboot());
      });
      break;
    case 6:
      confirm(N_("Shut Down"), N_("Shut down the computer?"), N_("Shut Down"), [] {
        if (g_host.before_shutdown) g_host.before_shutdown();
        report(power::poweroff());
      });
      break;
    case 7:
      if (g_host.open_power_panel) g_host.open_power_panel();
      break;
  }
}

Fl_Widget *make_power(int X, int Y, int W, int H) { return new PowerApplet(X, Y, W, H); }

void power_action(PowerAction a) { PowerApplet::act(nullptr, (void *)(long)a); }

bool power_action_available(PowerAction a) {
  switch (a) {
    case PowerAction::Lock: return !power::locker().empty();
    case PowerAction::Sleep: return g_power.can_suspend;
    case PowerAction::Hibernate: return g_power.can_hibernate;
    case PowerAction::LogOut: return true;
    case PowerAction::Restart: return g_power.can_reboot;
    case PowerAction::ShutDown: return g_power.can_poweroff;
  }
  return false;
}

// ---------------------------------------------------------------------------
// Multimedia keys, idleness, refreshing
// ---------------------------------------------------------------------------
static KeyCode k_up, k_down, k_mute, k_micmute, k_bup, k_bdown;
static int g_ss_event = -1;
static power::IdleSettings g_idle;
static int g_last_sleep_idle = 0;
static bool g_warned_low = false, g_critical_done = false;

static int ignore_errors(Display *, XErrorEvent *) { return 0; }

static void grab_keys() {
  Display *d = fl_display;
  Window root = DefaultRootWindow(d);
  auto kc = [&](KeySym s) { return XKeysymToKeycode(d, s); };
  k_up = kc(XF86XK_AudioRaiseVolume);
  k_down = kc(XF86XK_AudioLowerVolume);
  k_mute = kc(XF86XK_AudioMute);
  k_micmute = kc(XF86XK_AudioMicMute);
  k_bup = kc(XF86XK_MonBrightnessUp);
  k_bdown = kc(XF86XK_MonBrightnessDown);
  // GNOME/KDE hold these keys themselves - then XGrabKey ends with BadAccess and we do nothing
  XSync(d, False);
  auto old = XSetErrorHandler(ignore_errors);
  for (KeyCode k : {k_up, k_down, k_mute, k_micmute, k_bup, k_bdown})
    if (k) XGrabKey(d, k, AnyModifier, root, True, GrabModeAsync, GrabModeAsync);
  XSync(d, False);
  XSetErrorHandler(old);
}

static void apply_settings() {
  g_idle = power::read_idle();
  if (g_host.nirvana_session) power::apply_idle(g_idle);
}

static int x_events(void *event, void *) {
  XEvent *e = (XEvent *)event;
  if (e->type == KeyPress && e->xkey.window == DefaultRootWindow(fl_display)) {
    KeyCode k = e->xkey.keycode;
    if (k == k_up || k == k_down) {
      audio::step_volume(k == k_up ? 5 : -5);
      if (g_vol) g_vol->refresh(true);
      return 1;
    }
    if (k == k_mute) {
      audio::toggle_mute(true);
      if (g_vol) g_vol->refresh(true);
      return 1;
    }
    if (k == k_micmute) { audio::toggle_mute(false); if (g_vol) g_vol->refresh(false); return 1; }
    if (k == k_bup || k == k_bdown) {
      power::step_brightness(k == k_bup ? 10 : -10);
      g_power = power::query();
      if (g_power.brightness >= 0) osd(Osd::Brightness, g_power.brightness, false);
      if (g_pow) g_pow->sync();
      return 1;
    }
  }
  if (g_ss_event >= 0 && e->type == g_ss_event) {
    // the X screensaver started: lock (like xss-lock), unless a projection is running
    auto *se = (XScreenSaverNotifyEvent *)e;
    if (se->state == ScreenSaverOn && g_host.nirvana_session && g_idle.lock_on_blank && !power::projection() &&
        power::nirvana_lock().empty())   // with nirvana-lock the X blanking is off (saver_tick)
      power::lock_screen();
    return 0;
  }
  if (e->type == PropertyNotify && e->xproperty.window == DefaultRootWindow(fl_display) &&
      e->xproperty.atom == XInternAtom(fl_display, power::SETTINGS_ATOM, False)) {
    apply_settings();
  }
  return 0;
}

// Every 20 s: battery, brightness, sleeping when idle, warnings.
static void power_tick(void *) {
  g_power = power::query();
  if (g_pow) g_pow->sync();
  if (g_host.nirvana_session && !power::projection()) {
    int limit = g_power.on_ac ? g_idle.sleep_ac_min : g_idle.sleep_battery_min;
    int idle = power::idle_seconds();
    if (idle < g_last_sleep_idle) g_last_sleep_idle = 0;   // there was activity since the last sleep
    if (limit > 0 && idle >= limit * 60 && !g_last_sleep_idle && g_power.can_suspend) {
      g_last_sleep_idle = idle;
      if (g_idle.lock_on_blank) power::lock_screen();
      power::suspend();
    }
  }
  // battery: a warning at 10%, at 3% hibernate or sleep
  if (g_power.percent >= 0 && !g_power.on_ac) {
    if (g_power.percent <= 10 && !g_warned_low && g_host.dialog) {
      g_warned_low = true;
      g_host.dialog(_("Battery"), plat::fmt(_("The battery is almost empty (%1%). Plug in the power adapter."), std::to_string(g_power.percent)), {{"OK", nullptr}});
    }
    if (g_power.percent <= 3 && !g_critical_done && g_idle.critical_action && g_host.nirvana_session) {
      g_critical_done = true;
      if (g_idle.critical_action == 1 && g_power.can_hibernate) power::hibernate();
      else if (g_power.can_suspend) power::suspend();
    }
  } else {
    g_warned_low = g_critical_done = false;
  }
  Fl::repeat_timeout(20.0, power_tick);
}

const Host &current_host() { return g_host; }

int power_width() {
  int wdt = g_power.percent >= 0 ? 23 : 14;
  if (g_power.percent >= 0 && !g_power.charging) wdt += g_power.on_ac ? 9 : 8;
  if (power::projection()) wdt += 14;
  return wdt + 8;
}

// Every 2 s: idle long enough - Nirvana's screen saver (nirvana-lock --saver; it locks by itself
// when the settings say so). Not in presentation mode.
static int g_saver_idle = 0;
static void saver_tick(void *) {
  static std::string lock = power::nirvana_lock();
  if (g_host.nirvana_session && !lock.empty() && g_idle.blank_min > 0 && !power::projection()) {
    int idle = power::idle_seconds();
    if (idle < g_saver_idle) g_saver_idle = 0;   // there was activity since the saver started
    if (!g_saver_idle && idle >= g_idle.blank_min * 60) {
      g_saver_idle = idle;
      if (!power::saver_running()) power::start_saver();
    }
  }
  Fl::repeat_timeout(2.0, saver_tick);
}

void init(const Host &host) {
  g_host = host;
  if (host.nirvana_session) power::restore_profile();   // kernel profiles are forgotten at a restart
  fl_open_display();
  grab_keys();
  int ev, er;
  if (XScreenSaverQueryExtension(fl_display, &ev, &er)) {
    g_ss_event = ev + ScreenSaverNotify;
    XScreenSaverSelectInput(fl_display, DefaultRootWindow(fl_display), ScreenSaverNotifyMask);
  }
  Fl::add_system_handler(x_events, nullptr);
  apply_settings();
  g_power = power::query();
  if (g_host.relayout) g_host.relayout();   // the battery icon has its width now
  Fl::add_timeout(20.0, power_tick);
  Fl::add_timeout(2.0, saver_tick);
  audio::watch([] { if (g_vol) g_vol->refresh(false); });
}

}  // namespace applets
